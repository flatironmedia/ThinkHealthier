<?php 

include 'wrap-header.inc';
include 'wrap-body.inc';
include 'wrap-footer.inc';

?>