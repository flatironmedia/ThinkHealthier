<?php

$_SESSION['item_counter']=0;

$_SESSION['counter_reset'] = true;


?>