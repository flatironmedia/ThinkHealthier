<?php
/**
 * ------------------------------------------------------------------------
 * JA Nuevo template
 * ------------------------------------------------------------------------
 * Copyright (C) 2004-2011 J.O.O.M Solutions Co., Ltd. All Rights Reserved.
 * @license - Copyrighted Commercial Software
 * Author: J.O.O.M Solutions Co., Ltd
 * Websites:  http://www.joomlart.com -  http://www.joomlancers.com
 * This file may not be redistributed in whole or significant part.
 * ------------------------------------------------------------------------
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

/**
 * T3 Blank Helper class
 *
 * @package		T3 Blank
 */

/*
jimport('joomla.event.event');

class T3_BS3_BlankHook extends JEvent
{
	
	public function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);		
	}
	
	public function onT3Init() // no params
	{
		
	}

	public function onT3TplInit($t3app)
	{
		
	}

	public function onT3LoadLayout(&$path, $layout)
	{
		//T3::getApp()->addBodyClass('loadlayout');
	}

	public function onT3Spotlight(&$info, $name, $position)
	{
		
	}
	
	public function onT3Megamenu(&$menutype, &$config, &$levels)
	{
		
	}

	public function onT3BodyClass(&$class)
	{
		//$class[] = 'onbodyclass';
	}

	public function onT3BeforeCompileHead() // no params
	{
		
	}
	
	public function onT3BeforeRender() // no params
	{
		
	}
	
	public function onT3AfterRender() // no params
	{
		
	}
}

*/
?>